package com.example.tienda;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProductoController {
    @Autowired
    public ProductosServices productosServices;
    @Autowired
    public CategoriasService categoriaServices;

    @GetMapping({"/list" })
    public String showList(Model model) {
        model.addAttribute("listaProductos", productosServices.findAll());
        model.addAttribute("listaCategorias",categoriaServices.findAll());
        model.addAttribute("categoriaSeleccionada", "Todas");

        return "listView";
    }
    @GetMapping("/list/{idCat}")
    public String showListInCategory(@PathVariable Long idCat, Model model) {
    model.addAttribute("listaProductos", productosServices.findByCategory(idCat));
    model.addAttribute("listaCategorias", categoriaServices.findAll());
    model.addAttribute("categoriaSeleccionada", categoriaServices.findById(idCat).getNombre());
    return "listView";
    } 
    @GetMapping("/new")
    public String showNew(Model model ) {
        // el commandobject del formulario es una instancia de empleado vacia
        model.addAttribute("productoForm", new Productos());
        model.addAttribute("listaCategorias",categoriaServices.findAll());
        return "newFormView";
    }

    @PostMapping("/new/submit")
    public String showNewSubmit(
            @Valid @ModelAttribute("productoForm") Productos nuevoProducto,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors())
            return "editFormView";
        productosServices.add(nuevoProducto);
        return "redirect:/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable long id, Model model) {
        Productos productos = productosServices.findById(id);
        // el commandobject del formulario es el empleado con el id solicitado
        if (productos != null) {
            model.addAttribute("productoForm", productos);
            model.addAttribute("listaCategorias",categoriaServices.findAll());
            return "editFormView";
        }
        // si no lo encuentra vuelve a la página de inicio.
        return "redirect:/list";
    }

    @PostMapping("/edit/submit")
    public String showEditSubmit(
            @Valid @ModelAttribute("productoForm") Productos productos,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "editFormView";
        } else {
            productosServices.edit(productos);
            return "redirect:/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String showDelete(@PathVariable long id) {
        productosServices.delete(id);
        return "redirect:/list";
    }














    
    @GetMapping("/contactView")
    public String Contactos(Model model) {
        model.addAttribute("formInfo", new FormInfo());
        return "contactView";
    }

    @PostMapping("/contactView/submit")
    public String showContactSubmit(@Valid FormInfo formInfo, BindingResult bindingResult, Model model) {
        System.out.println(formInfo.getNombre());
        if (bindingResult.hasErrors()) {
            return "redirect:/contactView";
        } else {
            return "contactViewSubmit";
        }

    }

    @GetMapping("/aboutUs")
    public String Conocenos(Model modelo) {
        LocalDate anho = LocalDate.of(2022, 9, 27);
        modelo.addAttribute("anho", anho.getYear());
        return "aboutUs";

    }

    @GetMapping({ "/homeView", "", "home" })
    public String index(@RequestParam(required = false, defaultValue = "") String mensaje, Model model) {
        model.addAttribute("mensaje", mensaje);
        return "homeView";
    }

    @GetMapping("/productsView")
    public String Productos(Model ProdModelo) {
        List<String> listaProductos = new ArrayList<>(Arrays.asList("Producto1", "Producto2", "Producto3"));
        ProdModelo.addAttribute("Lista", listaProductos);
        return "productsView";
    }
}