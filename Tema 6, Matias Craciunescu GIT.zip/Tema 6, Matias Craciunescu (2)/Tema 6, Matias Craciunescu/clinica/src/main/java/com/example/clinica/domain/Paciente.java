package com.example.clinica.domain;

import java.time.LocalDate;

import com.example.clinica.config.Tarifas;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(of = "dni")
@NoArgsConstructor
public abstract class Paciente {
    private String dni;
    private String nombre;
    private LocalDate fechaNacimiento;
    public  abstract Double facturar(Tarifas tarifas);
}
