package com.example.clinica.domain;
    import java.util.List;

import com.example.clinica.config.Tarifas;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor

public class PacienteRecetas extends Paciente{
    private List<String>listaMedicamentos;
    @Override
    public Double facturar(Tarifas tarifas)
    {return tarifas.getTarifaReceta()*listaMedicamentos.size();}
}
    

