package com.example.clinica.services;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.clinica.config.Tarifas;
import com.example.clinica.domain.Paciente;
import com.example.clinica.domain.PacienteConsulta;
import com.example.clinica.domain.PacienteDTO;
import com.example.clinica.domain.PacienteRecetas;
import com.example.clinica.domain.PacienteRevision;

@Service
public class PacienteServiceImpnMem implements PacienteService {
    List<Paciente> repositorio = new ArrayList<>();

    @Autowired
    Tarifas tarifas;

    public void add(Paciente paciente) {
        repositorio.add(paciente);
    }

    public void deleteFirst() {
        if (repositorio.size() > 0)
            repositorio.remove(0);
    }

    public Paciente getFirst() {
        if (repositorio.size() > 0)
            return repositorio.remove(0);
        return null;
    }

    public List<Paciente> findAll() {
        return repositorio;
    }

    public Double facturar(Paciente paciente){
        if(paciente != null)
        return paciente.facturar(tarifas);
        else
        return 0d;
    }
    public Paciente buildPacientefromDTO(PacienteDTO PacienteDTO) {
        Paciente paciente;
        switch (PacienteDTO.getTipoPaciente()) {
            case 1 -> {
                paciente = new PacienteConsulta();
                ((PacienteConsulta) paciente).setMotivoConsulta(PacienteDTO.getMotivoConsulta());
            }
            case 2 -> {
                paciente = new PacienteRecetas();
                String[] med = PacienteDTO.getListaMedicamentos().split(",");
                ((PacienteRecetas) paciente).setListaMedicamentos(Arrays.asList(med));
            }
            case 3 -> {
                paciente = new PacienteRevision();
                ((PacienteRevision) paciente).setFechaUltimaRevision(PacienteDTO.getFechaUltimaRevision());
            }
            default -> {
                return null;
            }
        }
        paciente.setDni(PacienteDTO.getDni());
        paciente.setFechaNacimiento(PacienteDTO.getFechaNacimiento());
        paciente.setNombre(PacienteDTO.getNombre());
        return paciente;
    }
}
