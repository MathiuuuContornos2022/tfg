package com.example.clinica.domain;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import com.example.clinica.config.Tarifas;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor

public class PacienteRevision extends Paciente{
    private LocalDate fechaUltimaRevision;

    @Override
    public Double facturar(Tarifas tarifas){
        long edad= ChronoUnit.YEARS.between(this.getFechaNacimiento(), LocalDate.now());
        if(edad <=65)
        return tarifas.getTarifaRevisionAdulto();
        else
        return tarifas.getTarifaRevisionJubilado();
    }
}

