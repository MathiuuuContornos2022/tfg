package com.example.tienda;

import java.util.List;

public interface CuentasService {
    int delete(String iban);

    public Cuentas add(Cuentas ct);

    public List<Cuentas> findAll();

    public Cuentas findById(String id);

    public Cuentas edit(Cuentas ct);
}
