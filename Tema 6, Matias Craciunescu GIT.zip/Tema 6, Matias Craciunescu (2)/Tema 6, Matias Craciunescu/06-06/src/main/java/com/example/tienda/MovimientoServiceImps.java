package com.example.tienda;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class MovimientoServiceImps implements MovimientoService {
    private List<Movimiento> repositorio = new ArrayList<>();

    public Movimiento add(Movimiento p) {
        repositorio.add(p);
        return p;
    }

    public List<Movimiento> findAll() {
        return repositorio;
    }

    public Movimiento findById(String iban) {
        for (Movimiento p : repositorio)
            if (p.getIban().equals(iban))
                return p;
        return null;
    }

    public Movimiento edit(Movimiento p) {
        int pos = repositorio.indexOf(p);
        if (pos == -1)
            repositorio.add(p);
        else
            repositorio.set(pos, p);
        return p;
    }

    public int delete(String id) {
        Movimiento p = this.findById(id);
        if (p != null) {
            repositorio.remove(p);
            return 1;
        }
        return 0;
    }
    public List <Movimiento>findByCategory(String iban){
        ArrayList <Movimiento>listaProductos=new ArrayList<>();
        for (Movimiento p : repositorio)
            if (p.getIban().equals(iban) )
            listaProductos.add(p);
            return listaProductos;
        
    }
}
