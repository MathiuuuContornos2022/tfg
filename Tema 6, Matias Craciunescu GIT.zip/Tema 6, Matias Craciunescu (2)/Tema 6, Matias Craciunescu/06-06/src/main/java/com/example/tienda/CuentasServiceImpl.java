package com.example.tienda;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class CuentasServiceImpl implements CuentasService  {
    private List<Cuentas> repositorio = new ArrayList<>();

    public Cuentas add(Cuentas ct){
        repositorio.add(ct);
        return ct;
    }

    public List<Cuentas>findAll(){
        return repositorio;
    }

    public Cuentas findById(String iban) {
        for (Cuentas ct : repositorio)
            if (ct.getIban().equals(iban))
                return ct;
        return null;
    }

    public Cuentas edit(Cuentas ct) {
        int pos = repositorio.indexOf(ct);
        if (pos == -1)
            repositorio.add(ct);
        else
            repositorio.set(pos, ct);
        return ct;
    }

    public int delete(String iban) {
        Cuentas ct = this.findById(iban);
        if (ct != null) {
            repositorio.remove(ct);
            return 1;
        }
        return 0;
    }
}
