package com.example.tienda;

import java.util.List;

public interface MovimientoService {
    int delete(String iban);

    public Movimiento add(Movimiento p);

    public List<Movimiento> findAll();

    public Movimiento findById(String id);

    public Movimiento edit(Movimiento p);

    public List<Movimiento> findByCategory(String idCat);
}
