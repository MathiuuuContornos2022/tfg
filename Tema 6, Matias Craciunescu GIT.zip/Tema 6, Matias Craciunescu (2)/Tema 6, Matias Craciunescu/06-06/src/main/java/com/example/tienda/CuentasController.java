package com.example.tienda;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cuentas")
public class CuentasController {

    @Autowired
    public CuentasService cuentasService;

    @GetMapping( "/" )
    public String cuentas(Model model) {
        model.addAttribute("cuentas", cuentasService.findAll());
        return "cuentasView";
    }

    @GetMapping("/cuentasNew")
    public String cuentasNew(Model model) {
        model.addAttribute("cuentaNew", new Cuentas());
        model.addAttribute("listaCuentas", cuentasService.findAll());
        return "cuentasNewView";
    }

    @PostMapping("/cuentasNew/submit")
    public String showNewSubmit(
        @Valid @ModelAttribute("cuentasNew") Cuentas cuentas,
        BindingResult bindingResult){
            if (bindingResult.hasErrors()) 
            return "cuentasNewView";
            cuentasService.add(cuentas);
            return "redirect:/cuentas/";
        
    }

    @GetMapping("/edit/{id}")
    public String editCuentas(@PathVariable String id, Model model) {
        Cuentas cuentas=cuentasService.findById(id);
        if(cuentas != null) {
            model.addAttribute("cuentasNew", cuentas);
            return "editcuentas";
}
        return "redirect:/cuentas";
}
    @PostMapping("edit/submit")
    public String showCuentasSubmit(
        @Valid @ModelAttribute("cuentasNew") Cuentas cuentas,
        BindingResult bindingResult){
            if (bindingResult.hasErrors()) {
            return "editCuentas";
        } else{
            cuentasService.edit(cuentas);
            return "redirect:/cuentas/";
        }
}
    @GetMapping("/delete/{id}")
    public String showCuentas(@PathVariable String id) {
        cuentasService.delete(id);
        return "redirect:/cuentas/";
}
}