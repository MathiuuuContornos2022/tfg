package com.example.tienda;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "iban")
public class Movimiento {
    private String iban;
    private double importe;
    private String fecha;
    
}
