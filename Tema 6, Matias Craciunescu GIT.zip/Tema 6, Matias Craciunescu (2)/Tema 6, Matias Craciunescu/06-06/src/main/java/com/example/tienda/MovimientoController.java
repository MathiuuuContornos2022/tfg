package com.example.tienda;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/movimientos")
public class MovimientoController {
    @Autowired
    public MovimientoService movimientoService;
    
    @Autowired
    public CuentasService cuentasService;

    @GetMapping( "/")
    public String showList(Model model) {
        model.addAttribute("Movimientos", movimientoService.findAll());
        model.addAttribute("Cuentas", cuentasService.findAll());
        model.addAttribute("categoriaEspecifica", "Todas");
        return "movimientosListView";
    
    }

    @GetMapping("/list/{idCategoria}")
    public String showListInCategory(@PathVariable String idCategoria, Model model) {
        model.addAttribute("Movimientos", movimientoService.findByCategory(idCategoria));
        model.addAttribute("Categorias", cuentasService.findAll());
        model.addAttribute("categoriaEspecifica", cuentasService.findById(idCategoria).getIban());
        return "movimientosListView";
    }

    @GetMapping("/new")
    public String showNew(Model model) {
        model.addAttribute("movimientoForm",new Movimiento());
        model.addAttribute("Cuentas", cuentasService.findAll());
        return "newFormViewMovimientos";
    }

    @PostMapping("/new/submit")
    public String showNewSubmit(
            @Valid @ModelAttribute("empleadoForm") Movimiento nuevoMovimiento,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors())
            return "editFormViewMovimientos";
        movimientoService.add(nuevoMovimiento);
        return "redirect:/movimientos/";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable String id, Model model) {
        Movimiento movimiento = movimientoService.findById(id);
        if (movimiento != null) {
            model.addAttribute("Categorias", cuentasService.findAll());
            model.addAttribute("movimientoForm", movimiento);
            return "editFormViewMovimientos";
        }
        return "redirect:/";
    }

    @PostMapping("/edit/submit")
    public String showEditSubmit(
            @Valid @ModelAttribute("empleadoForm") Movimiento movimiento,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "editFormViewMovimientos";
        } else {
            movimientoService.edit(movimiento);
            return "redirect:/movimientos";
        }
    }

    @GetMapping("/delete/{id}")
    public String showDelete(@PathVariable String id) {
        movimientoService.delete(id);
        return "redirect:/movimientos/";
    }
}

