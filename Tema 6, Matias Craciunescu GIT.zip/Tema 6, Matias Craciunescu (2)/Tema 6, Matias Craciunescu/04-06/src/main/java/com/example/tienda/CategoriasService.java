package com.example.tienda;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class CategoriasService {
    private List<Categoria> repositorio = new ArrayList<>();

    public Categoria add(Categoria ct){
        repositorio.add(ct);
        return ct;
    }

    public List<Categoria>findAll(){
        return repositorio;
    }

    public Categoria findById(long id) {
        for (Categoria ct : repositorio)
            if (ct.getId() == id)
                return ct;
        return null;
    }

    public Categoria edit(Categoria ct) {
        int pos = repositorio.indexOf(ct);
        if (pos == -1)
            repositorio.add(ct);
        else
            repositorio.set(pos, ct);
        return ct;
    }

    public int delete(Long id) {
        Categoria ct = this.findById(id);
        if (ct != null) {
            repositorio.remove(ct);
            return 1;
        }
        return 0;
    }
}
