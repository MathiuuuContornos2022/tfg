package com.example.tienda;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    @Autowired
    public CategoriasService categoriasService;

    @GetMapping( "/" )
    public String categorias(Model model) {
        model.addAttribute("categoriasView", categoriasService.findAll());
        return "categorias";
    }

    @GetMapping("/categoriaNew")
    public String categoriaNew(Model model) {
        model.addAttribute("categoriaNew", new Categoria());
        return "categoriaNewView";
    }

    @PostMapping("/categoriaNew/submit")
    public String showNewSubmit(
        @Valid @ModelAttribute("categoriaNew") Categoria categoria,
        BindingResult bindingResult){
            if (bindingResult.hasErrors()) 
            return "categoriaNewView";
            categoriasService.add(categoria);
            return "redirect:/categorias/";
        
    }

    @GetMapping("/edit/{id}")
    public String editCategorias(@PathVariable long id, Model model) {
        Categoria categoria=categoriasService.findById(id);
        if(categoria != null) {
            model.addAttribute("categoriaNew", categoria);
            return "editCategorias";
}
        return "redirect:/categorias";
}
    @PostMapping("edit/submit")
    public String showCategoriaSubmit(
        @Valid @ModelAttribute("categoriaNew") Categoria categoria,
        BindingResult bindingResult){
            if (bindingResult.hasErrors()) {
            return "editCategorias";
        } else{
            categoriasService.edit(categoria);
            return "redirect:/categorias/";
        }
}
    @GetMapping("/delete/{id}")
    public String showCategorias(@PathVariable long id, Model model) {
        categoriasService.delete(id);
        return "redirect:/categorias/";
}
}