package com.example.empleado;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class EmpleadoService {
    private List<Empleado> repositorio = new ArrayList<>();

    public Empleado add(Empleado e) {
        repositorio.add(e);
        return e;
    }

    public List<Empleado> findAll() {
        return repositorio;
    }

    public Empleado findById(long id) {
        for (Empleado e : repositorio)
            if (e.getId() == id)
                return e;
        return null;
    }

    public Empleado edit(Empleado e) {
        int pos = repositorio.indexOf(e);
        if (pos == -1)
            repositorio.add(e);
        else
            repositorio.set(pos, e);
        return e;
    }

    public int delete(Long id) {
        Empleado e = this.findById(id);
        if (e != null) {
            repositorio.remove(e);
            return 1;
        }
        return 0;
    }
}
