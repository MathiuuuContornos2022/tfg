package com.example.empleado;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaApplication.class, args);
	}
		@Bean
 CommandLineRunner initData(EmpleadoService empleadoService) {
 return args -> {
 empleadoService.add(
 new Empleado(1L, "pepe", "pepe@gmail.com", 1000d, true, "masculino"));
 empleadoService.add(
 new Empleado(2L, "ana", "ana@gmail.com", 2000d, true, "femenino"));
 };
 }
	}

