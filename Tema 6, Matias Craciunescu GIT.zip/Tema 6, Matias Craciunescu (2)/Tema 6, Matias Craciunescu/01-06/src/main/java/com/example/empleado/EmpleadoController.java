package com.example.empleado;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EmpleadoController {
    @Autowired
    public EmpleadoService empleadoService;

    @GetMapping({ "/", "/list" })
    public String showList(Model model) {
        model.addAttribute("listaEmpleados", empleadoService.findAll());
        return "listView";
    }

    @GetMapping("/new")
    public String showNew(Model model) {
        // el commandobject del formulario es una instancia de empleado vacia
        model.addAttribute("empleadoForm", new Empleado());
        return "newFormView";
    }

    @PostMapping("/new/submit")
    public String showNewSubmit(
            @Valid @ModelAttribute("empleadoForm") Empleado nuevoEmpleado,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors())
            return "newForm";
        empleadoService.add(nuevoEmpleado);
        return "redirect:/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable long id, Model model) {
        Empleado empleado = empleadoService.findById(id);
        // el commandobject del formulario es el empleado con el id solicitado
        if (empleado != null) {
            model.addAttribute("empleadoForm", empleado);
            return "editFormView";
        }
        // si no lo encuentra vuelve a la página de inicio.
        return "redirect:/";
    }

    @PostMapping("/edit/submit")
    public String showEditSubmit(
            @Valid @ModelAttribute("empleadoForm") Empleado empleado,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "editFormView";
        } else {
            empleadoService.edit(empleado);
            return "redirect:/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String showDelete(@PathVariable long id) {
        empleadoService.delete(id);
        return "redirect:/list";
    }
}
