package com.example.empleado;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")

public class Empleado {
    @Min(value = 0)
 private Long id;
 @NotEmpty
 private String nombre;
 @Email(message = "Debe tener formato email valido")
 private String email;
 private Double salario;
 private boolean enActivo;
 private String genero; 

}