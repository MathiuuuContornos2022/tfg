package com.example.tienda;
 import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
 @Service
public class ProductosServices {
    private List<Productos> repositorio = new ArrayList<>();

    public Productos add(Productos pr) {
        repositorio.add(pr);
        return pr;
    }

    public List<Productos> findAll() {
        return repositorio;
    }

    public Productos findById(long id) {
        for (Productos pr : repositorio)
            if (pr.getId() == id)
                return pr;
        return null;
    }

    public Productos edit(Productos pr) {
        int pos = repositorio.indexOf(pr);
        if (pos == -1)
            repositorio.add(pr);
        else
            repositorio.set(pos, pr);
        return pr;
    }

    public int delete(Long id) {
        Productos pr = this.findById(id);
        if (pr != null) {
            repositorio.remove(pr);
            return 1;
        }
        return 0;
    }
}
