package com.example.tienda;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
public class FormInfo {
    @NotEmpty
    private String nombre;
    @Email
    private String email;
    @NotEmpty
    private String motivo;
    @Size (max=255)
    private String comentarios;
    private boolean aceptarCondiciones;
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getMotivo() {
        return motivo;
    }
    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
    public String getComentarios() {
        return comentarios;
    }
    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }
    public boolean isAceptarCondiciones() {
        return aceptarCondiciones;
    }
    public void setAceptarConcidiones(boolean aceptarCondiciones) {
        this.aceptarCondiciones = aceptarCondiciones;
    }

}
